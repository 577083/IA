﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Configuration;
using System.IO;

namespace FileUploader
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        #region "ValidateFileSize"
        protected void ValidateFileSize(object sender, ServerValidateEventArgs e)
        {
            try
            {
                //Add Code Here
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region "Upload_Click"
        protected void Upload_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                //Add Code Here
            }
                
        }
        #endregion
    }
}
